// Mostrar formulário de cadastro
document.getElementById('showRegisterForm').addEventListener('click', () => {
    document.getElementById('loginFormContainer').style.display = 'none';
    document.getElementById('registerFormContainer').style.display = 'block';
});

// Mostrar formulário de login
document.getElementById('showLoginForm').addEventListener('click', () => {
    document.getElementById('registerFormContainer').style.display = 'none';
    document.getElementById('loginFormContainer').style.display = 'block';
});

// Cadastro de usuário
document.getElementById('registerForm').addEventListener('submit', async (e) => {
    e.preventDefault();

    const email = document.getElementById('registerEmail').value;
    const senha = document.getElementById('registerSenha').value;

    // Enviar a requisição POST para cadastro
    const response = await fetch('/cadastro', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email, senha })
    });

    const data = await response.json();

    if (response.status === 201) {
        alert(data.message);
        document.getElementById('registerFormContainer').style.display = 'none';
        document.getElementById('loginFormContainer').style.display = 'block';
    } else {
        alert(data.message);
    }
});

// Login de usuário
document.getElementById('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const email = document.getElementById('loginEmail').value;
    const senha = document.getElementById('loginSenha').value;

    // Enviar a requisição POST para login
    const response = await fetch('/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email, senha })
    });
    
    const data = await response.json();
    
    if (response.status === 200) {
        // Exibir perfil do usuário
        document.querySelector('.container').style.display = 'none';
        const perfilDiv = document.getElementById('perfil');
        perfilDiv.style.display = 'block';
        document.getElementById('userEmail').textContent = `Email: ${data.usuario.email}`;
    } else {
        alert(data.message);
    }
});

// Função para Logout (DELETE)
document.getElementById('logoutBtn').addEventListener('click', async () => {
    const response = await fetch('/usuario/1', {
        method: 'DELETE'
    });

    const data = await response.json();
    alert(data.message);
    location.reload();  // Recarrega a página
});
