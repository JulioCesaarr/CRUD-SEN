const express = require("express");
const app = express();
const port = 3000;

// Base de dados simulada
let users = [];

// Middleware para interpretar JSON
app.use(express.json());
app.use(express.static("public"));

// Rota para registrar um novo usuário
app.post("/users", (req, res) => {
    const { username, password } = req.body;

    // Verificando se os campos são obrigatórios
    if (!username || !password) {
        return res.status(400).json({ message: "Username e senha são obrigatórios!" });
    }

    // Verificando se o usuário já existe
    const userExists = users.some(user => user.username === username);
    if (userExists) {
        return res.status(400).json({ message: "Usuário já existe!" });
    }

    // Adicionando o usuário na "base de dados"
    users.push({ username, password });
    res.json({ message: "Usuário cadastrado com sucesso!" });
});

// Rota para autenticação de login
app.post("/login", (req, res) => {
    const { username, password } = req.body;

    // Verificando as credenciais
    const user = users.find(user => user.username === username && user.password === password);
    if (user) {
        res.json({ message: "Login realizado com sucesso!" });
    } else {
        res.status(401).json({ message: "Credenciais inválidas!" });
    }
});

// Rota para editar um usuário (alterar senha)
app.put("/users", (req, res) => {
    const { username, password, newPassword } = req.body;

    // Verificando se todos os campos foram preenchidos
    if (!username || !password || !newPassword) {
        return res.status(400).json({ message: "Username, senha atual e nova senha são obrigatórios!" });
    }

    // Verificando se o usuário existe
    const user = users.find(user => user.username === username && user.password === password);
    if (user) {
        // Atualizando a senha do usuário
        user.password = newPassword;
        res.json({ message: "Senha atualizada com sucesso!" });
    } else {
        res.status(404).json({ message: "Usuário não encontrado ou senha incorreta!" });
    }
});

// Rota para deletar um usuário
app.delete("/users", (req, res) => {
    const { username } = req.body;

    // Verificando se o nome de usuário foi informado
    if (!username) {
        return res.status(400).json({ message: "O username é obrigatório!" });
    }

    // Buscando o índice do usuário para remover
    const userIndex = users.findIndex(user => user.username === username);
    if (userIndex !== -1) {
        // Deletando o usuário
        users.splice(userIndex, 1);
        res.json({ message: "Usuário deletado com sucesso!" });
    } else {
        res.status(404).json({ message: "Usuário não encontrado!" });
    }
});

// Inicializando o servidor
app.listen(port, () => {
    console.log(`Servidor rodando em http://localhost:${port}`);
});
